db.dropDatabase();
